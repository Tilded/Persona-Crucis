# GobboNet script handoff — verified latest version

Use `GobboNet_Mara_M4UI_customCode.js` as the exact runtime script to work on. It was extracted from the current ArcanaPersona `SOUL_SCRIPT` export and verified byte-for-byte against `Mara_Sayegh_GobboNet_Card_Milestone4UI.json`.

- UTF-8 bytes: 103697
- SHA-256: `b1a65db4913942c01f5f3077c9f83319d611df83389f43242aa7bfe3935c2de3`
- Version: M4UI / Milestone 4UI
- Wrapper source: `soulScript.ts`
- Real card carrying the same script: `Mara_Sayegh_GobboNet_Card_Milestone4UI.json`
- Lifecycle/UI harness: `Mara_UI_test.html`

`MILESTONE4UI_NOTES.md` describes what the latest UI script adds. `ARCANAPERSONA_SOUL_CONTRACT.md` is useful for the storage and carousel contracts, but its old sentence naming M3 as canonical is superseded by M4UI; use the M4UI card and notes as the version authority. Milestones 1–3 are older. The standalone GobboNet workspace/card is also older than this M4UI script.
