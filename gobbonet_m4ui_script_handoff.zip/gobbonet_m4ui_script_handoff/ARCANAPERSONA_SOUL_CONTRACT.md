# ArcanaPersona Soul Card Contract

This contract describes the card fields and carousel output required for a generator to emit a soul-enabled GobboNet character card with the M2/M3 card-side script.

## Required card fields

- `id`: a valid, non-empty GobboNet card identifier. Keep it stable for the exported card and unique among cards in the collection.
- `name`: a populated character display name. The script reads this at evaluation time from `gobbo.card.name` and uses it in prompts, context headers, and its activation log.
- `customCode`: non-empty; emit the script verbatim from `Mara_Sayegh_GobboNet_Card_Milestone3.json`.
- `customCodeEnabled`: `true`. GobboNet may disable imported/transferred code; the user must enable it in the card.

The script assumes the card is active when it is evaluated. It also assumes `gobbo.thread.id` remains stable throughout a session, because that ID selects the per-thread state entry.

## Store ownership and shapes

`gobbo.store` is scoped per card by GobboNet. The keys below are therefore already isolated across cards; the generator does not need to add a character prefix or otherwise namespace them. Preserve the names exactly so existing card data remains usable.

| Key | Scope and shape |
|---|---|
| `maraContinuityV2` | Object keyed by thread ID. Each value stores `familiarity`, `trust`, `warmth`, `romanticInterest`, and `friction` (clamped integer scores); `userFacts` (up to 12 `{text, sourceQuote}` records); `commitments` (up to 8 records with `key`, `kind`, `status`, `day`, `period`, `date`, `venue`, `exactTime`, and `userEvidenceQuote`); `maraLife` (up to five active `{key, summary, status, sourceQuote, sourceThread, updatedAt}` threads; closed/paused history may also remain); `psychology` (`coreIdentity`; `internalState` with `primaryEmotion`, `intensity`, `psychologicalTension`, `emotionalDecayCounter`, `emotionUpdatedAt`, and `sourceQuote`; `cognitiveDrive` with `activeAgenda` and `immediateFocus`; `cognitiveDissonance`; `updatedAt`); and `updatedAt`. |
| `maraIntellectualStateV1` | Character-wide object: `{version: 1, records: [], updatedAt}`. Each record represents a considered view and carries its topic/type/position/reasoning, confidence/status, supporting and opposing evidence, quote provenance, revision history, and timestamps. |
| `maraTopicsV1` | Object keyed by thread ID. Each value is `{topics, lastProcessedCount, mode, backups, topicUpdatedAt}`. `topics` maps filenames to text; `lastProcessedCount` is the processed-message counter; `mode` is 0–3; `backups` keeps up to five timestamped topic snapshots; `topicUpdatedAt` maps filenames to timestamps. Diary files use `Diary_YYYY-MM-DD.md` and the script's `diary_` retrieval exclusion remains unchanged. |
| `maraProactiveScheduleV1` | Scheduler setup state, normally `{initialized, threadId, scheduleId}`; `enabled: false` can disable initialization. The native schedule ID and this key are owned by the script. |

The script can initialize missing entries itself. Generators must not rename these keys or alter their stored data shapes.

## Carousel contract

For a soul-enabled export, set:

```json
{
  "carouselEnabled": true,
  "carouselMode": "random",
  "carouselPrompts": "This turn, …\nThis turn, …"
}
```

`carouselPrompts` is a newline-separated list of 8–12 lines. Every line must be at most 100 characters and begin with `This turn, …`. Lines may guide mood or behavior only. They must never invent events or plans, attribute feelings to the user, or escalate romance.

The context hook injects the saved continuity block as the authority for the character's current state. Carousel prompts should layer underneath that block and never contradict it. Treat a line as a light delivery/mood cue, not a new fact or state update.

Good patterns:

- `This turn, she is attentive to details before drawing a conclusion.`
- `This turn, he is dryly amused by an overly tidy explanation.`
- `This turn, they are quiet and deliberate with their words.`

Bad patterns:

- `This turn, she has just lost an important archive.` — invents an event.
- `This turn, she plans to visit the user tomorrow.` — invents a plan.
- `This turn, she is falling in love with the user.` — attributes feelings about the user and escalates romance.

## Suggested sampler profile

The M1/M2 Mara card provides a canonical reference profile: temperature `0.82`, Min-P `0.06`, top-K `40`, top-P `0.92`, repeat penalty `1.08`, and repeat-last-N `64`. Treat these as a suggested starting point, not script settings. Min-P, top-K, top-P, temperature, and repetition penalty are inherited from the generated card; the script does not set them. A generator may choose other card-level values when appropriate for its character/model.

## Explicit non-requirements

The script does not depend on a particular lorebook, greeting, avatar, or writingStyle. The only writingStyle expectation is that the character speaks in natural prose as `{{char}}`. No specific greeting, lore entry, or avatar is required.

## Generator checklist

1. Emit `customCode` verbatim from `Mara_Sayegh_GobboNet_Card_Milestone3.json`.
2. Generate 8–12 carousel lines that follow this contract.
3. Set `customCodeEnabled: true`.
4. Optionally set `carouselEnabled: true` (the recommended soul-enabled profile sets it to true along with random mode).

