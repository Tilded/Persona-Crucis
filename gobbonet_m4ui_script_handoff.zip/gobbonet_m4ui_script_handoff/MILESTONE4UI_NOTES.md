﻿# Milestone 4UI Notes

## HUD and data source

The HUD reads the active thread's existing `gobbo.store.maraContinuityV2`, `maraTopicsV1`, and character-wide `maraIntellectualStateV1` data. It displays primary emotion, intensity and decay counter; trust and warmth bars with the same qualitative bands used by the relationship-description helper; romantic and friction bars only when nonzero; and an analysis-age status dot. The expanded panel adds core identity, tension, agenda, focus, dissonance, active life threads, the last eight verified user facts, active commitments and missing-logistics markers, intellectual/topic counts, mode controls and the last-analysis time.

The small gear opens settings. The compact surface can be dismissed and restored from settings. The visible mode choices are Full, Index+Diary, Index only and Diary only. Mode writes only the current thread's existing `maraTopicsV1[threadKey].mode` field.

## `maraUIv1` preferences

Defaults are created on activation and saved. Keys:

- `hudVisible`: compact HUD visibility, default `true`.
- `expanded`: expanded panel state, default `false`.
- `offsetX`, `offsetY`: draggable pixel offsets, both default `0`; drag the HUD header to reposition the HUD and gear together.
- `showDiaryInThread`: settings checkbox preference, default `false`.
- `settingsOpen`: settings-panel visibility, default `false`.
- `errorsByThread`: last thrown analysis error per thread for the status dot and tooltip.
- `resetArmed`: transient inline thread-reset confirmation state.

The HUD uses direct, guarded reads and local display copies; it does not initialize or modify continuity/topic state just by rendering. Its explicit mode control writes the existing per-thread mode setting. UI preferences are the only new persisted key; no existing store key names or shapes changed. The reset action clears only `maraContinuityV2[threadKey]` and `maraTopicsV1[threadKey]`; it leaves the character-wide intellectual ledger intact. Export downloads only the active thread's continuity/topic entries plus the character-wide intellectual ledger.

## Diary wiring

The hard-coded `SHOW_DIARY_IN_THREAD` constant was replaced with a read of `gobbo.store.maraUIv1.showDiaryInThread`. The new checkbox defaults off and controls only whether the existing diary result is shown through `gobbo.note`; diary generation and validation are unchanged.

## DOM and failure handling

The card injects one HUD root and one inline style element on `activate`, and removes both on `deactivate`. Each has `gobbonet-ext` and a stable `data-mara-ui` attribute; all rendered controls and sections carry the same marker. The HUD is fixed at the top right with z-index 900. No `web/` tree or numeric GobboNet z-index scale was present in the supplied workspace, and the guide gives no number; 900 is a moderate local layer value rather than an extreme overlay value.

DOM access/rendering and HUD store reads are isolated by try/catch wrappers and logged with `gobbo.log`. If rendering fails, the root shows a red error state and tooltip when possible. A thrown continuity analysis records a per-thread UI error; a later successful or no-op analysis clears it. Force analysis calls the existing closure directly. The busy guard, captured thread, six-reply cadence, quote checks, clamps, prompt guards, and scheduled-check cleanup remain in place.

## Standalone harness

Open `Mara_UI_test.html` locally. It embeds the M4UI card script and mocks the GobboNet card, thread, store, hooks, scheduler, `ask`, notes, save and logging APIs. The seeded data populates the HUD. Controls simulate successful/failed analyses, three consecutive emotion-decay cycles, a typed inline thread reset, and deactivate/activate lifecycle switches. The harness has no network or external dependencies.

A strict-mode VM smoke run exercised render, settings and mode writes, analysis-error state, typed thread-only reset, ledger preservation, and repeated deactivate/activate teardown. A live GobboNet card-switch run was not available; the harness switch control provides the manual lifecycle check. Browser preview could not be completed because the available Computer Use browser selector rejected the local-file state as unverifiable.

## ArcanaPersona re-embed

Milestone B ZIP: `arcanapersona_milestone_b.zip`.

The embedded `SOUL_SCRIPT` and the M4UI card `customCode` are 103,697 UTF-8 bytes with SHA-256 `b1a65db4913942c01f5f3077c9f83319d611df83389f43242aa7bfe3935c2de3`. The seeded generator PNG fixture is 156,467 bytes, and the full payload survives extraction. The canonical test command for this checkout is `bun test` in `arcanapersona/`; Bun 1.4.4 reports 12 passed, 0 failed. `package.json` has no `test` script, so `bun test` is the working project runner.

## Deviations and found but did not fix

- Â§3.2's `sow_variables` / `[CURRENT STATE CHARACTERISTICS]` injection and `<state_update>` parser remain deferred; they are not in revised Â§7.4 and were explicitly excluded from this UI milestone.
- The supplied GobboNet source card `gobbonet-character-mara-sayegh-2026-11-02.json` was absent. M3 was the available current-card baseline.
- Relationship/psychology state does not have SoW-style five-generation snapshots, and its full-index minimum-size guard is not implemented. Topic snapshots, short topic/diary rejection, and quote provenance checks remain. These surfaced in the audit and are listed for a separate follow-up; no unrelated storage behavior was changed.
- A live GobboNet card-switch and browser visual review were not available. The harness and strict-mode VM smoke provide mocked lifecycle coverage.
- No TTS, STT or call-mode code was added.



