# TTS Readiness

**READY FOR TTS TIER 1: YES**

The §7.4 build order is complete through ArcanaPersona exports, and the missing existing-state HUD/settings surface is now implemented as Milestone 4UI. Every Phase 1 audit item is either complete or explicitly deferred below. No TTS, STT, or call-mode code has been started.

## Current verified artifacts

- Current card: `Mara_Sayegh_GobboNet_Card_Milestone4UI.json`; `customCodeEnabled: true`. Its HUD and settings panel render from existing store data. Strict-mode VM smoke covered rendering, mode and preference writes, failure status, typed per-thread reset without deleting the character-wide ledger, and repeated activate/deactivate teardown.
- Card customCode SHA-256: `b1a65db4913942c01f5f3077c9f83319d611df83389f43242aa7bfe3935c2de3` (103,697 UTF-8 bytes).
- ArcanaPersona Milestone B bundle: `arcanapersona_milestone_b.zip`. It embeds this M4UI script by default; `SOUL_SCRIPT` has the same SHA-256. The seeded full-payload PNG round-trip measured 156,467 bytes and extracted the script intact.
- Canonical available project test command: `bun test` from `arcanapersona/` — 12 passed, 0 failed. The package defines no `test` script.

## Audit dispositions

- **DONE:** §3.1 storage split, six-reply trigger, busy/thread-capture guards, Full/Lite router, no-op and parse retry, Archivist/Diary checks, topic selection, mode semantics, context injection and caps, quote verification, deterministic decay, native lorebooks/RAG, revised §7.4 steps 1–3, ArcanaPersona card paths, carousel contract, toggle, and PNG round-trip.
- **DONE:** §3.1 settings surface, §3.2 existing-state HUD, and §3.7 visible emotion chip. Diary visibility now reads `maraUIv1.showDiaryInThread`.
- **DONE:** Phase 2 hygiene: the legacy carousel array comment, stale Milestone 3 checklist, distribution/storage note, and canonical test-runner note are corrected.
- **DONE as an audit result:** TTS (§3.4), STT (§3.5), and call mode (§3.6) remain unimplemented as required before this milestone. They are the upcoming work, not blockers to beginning Tier 1.
- **DEFERRED UNTIL AFTER TTS:** §3.2 `sow_variables`, `[CURRENT STATE CHARACTERISTICS]` / `[SYSTEM DIRECTIVE — STATE UPDATES]`, `<state_update>` parsing, and delta application. These are outside revised §7.4 and were explicitly excluded from Milestone 4UI.
- **DEFERRED UNTIL AFTER TTS:** the audit's remaining supplementary Soul Memory gaps: five-generation continuity/psychology backups and full rewritten-index minimum-size checks. Existing five-deep topic backups, short topic/diary rejection, quote provenance, clamps, no-op behavior, and parse-failure retry remain intact.

The dated v1 GobboNet card cited by the guide was not present; the available M1–M3 cards were audited, and no claim about the absent export was relied upon. The live GobboNet app was unavailable for a card-switch check; the standalone mock harness and VM lifecycle smoke are included for review. The next authorized milestone may begin TTS Tier 1.
