# Audit Before TTS

Audit scope: inspected the Port Guide in full, workspace milestone notes/contracts, available M1–M3 cards, and the extracted ArcanaPersona source. The dated source card `gobbonet-character-mara-sayegh-2026-11-02.json` named by the guide was not present in the workspace. The available M3 export is therefore the current card baseline; claims about the missing v1 card are not treated as verified.

## §3.1 Soul Memory port

| Item | Section | Status | Evidence | Notes |
|---|---|---|---|---|
| `gobbo.store` storage, thread relationship split and character-wide intellectual state | §3.1; §6.2–6.3 | DONE | `arcanapersona/src/data/soul/soulScript.ts:21,29,70–90,136–141,881–888,1022–1033` | Relationship/topic data is indexed by captured thread id; `maraIntellectualStateV1` is a distinct character-wide key. |
| `gobbo.every(n, …)`, busy flag, thread captured before async | §3.1; §6.4 | DONE | `soulScript.ts:22,36,881–893,1040,1231` | Cadence remains six replies. `sourceThread` and `sourceThreadId` are captured before awaited work. |
| Router, Full/Lite prompts, no-op and parse failure behavior | §3.1 | DONE | `soulScript.ts:148–153,947–998,1034–1040` | `extractJson` failure returns without advancing the topic counter; explicit no-op also returns before writes/counter advancement. |
| Archivist prompt, marker extraction and minimum-length rejection | §3.1 | DONE | `soulScript.ts:154–159,998–1001` | Prompt retains the guide's wording and markers; extracted body under 50 characters is rejected. |
| Diary prompt, sentence/person checks, visibility setting | §3.1 | PARTIAL | `soulScript.ts:161–167`; constant at `:30` | Four-to-six sentence and first-person checks exist. `SHOW_DIARY_IN_THREAD` is hard-coded false, so there is no usable settings surface yet. Phase 3 permits wiring it to UI preference only. |
| Context injection, 4,500/2,500 caps and placement | §3.1; §6.5 | DONE | `soulScript.ts:27,30,169,1180–1222` | Continuity block is capped at 4,500 characters, deep topics at 2,500; insertion is immediately before the last user message. |
| Topic retrieval without embeddings; LLM selection and excerpt catalog | §3.1 | DONE | `soulScript.ts:148–153,928–937` | At most four topic files are sent directly; above four, the LLM selects from 600-character excerpts. |
| Deterministic emotional decay, backups, minimum lengths, parse retry, source-quote checks | §3.1; §7.5 | PARTIAL | `soulScript.ts:145,269–355,881–1040` | Decay is deterministic; topic snapshots keep five; malformed router output retries on a later cycle; facts, life, and psychology have quote checks. Soul-style five-deep backups for the relationship/psychology state are not present, and minimum-length rejection is for topic/diary content rather than full rewritten index files. |
| Modes 0–3 | §3.1 | DONE | `soulScript.ts:133–141,917–924,998–1001,1034–1037` | 0 Full; 1 Lite + Diary; 2 Lite/index only; 3 Diary only. |
| “Small MaraSoul settings surface” | §3.1; §3.8 step 1 | NOT DONE | `MILESTONE2_NOTES.md` describes only activation logging; `soulScript.ts:1232–1236` | Implemented as a mode log/instruction only, not a real UI. This is a missing design-doc UI and Phase 3 will build it. |

## §3.2 State variables and HUD

| Item | Section | Status | Evidence | Notes |
|---|---|---|---|---|
| `sow_variables` definitions and prompt injection | §3.2; §1.4 | NOT DONE | No `sow_variables`, `CURRENT STATE CHARACTERISTICS`, or `variables_state` in M3 customCode | Not in revised build order; would be separate scope. Deferred pending separate scope. |
| `<state_update>` parsing and delta application | §3.2; §1.4 | NOT DONE | No `<state_update>` parser or `variables_state` in M3 customCode | Not in revised build order; would be separate scope. Deferred pending separate scope. |
| Existing-state HUD for relationship, psychology, life, facts, commitments, ledger, topics and timestamp | §3.2; §3.7; §3.8 step 1 | NOT DONE | M3 customCode has no `gobbonet-ext` HUD or activation/deactivation UI handlers; state fields are present in `soulScript.ts:38–62,176–184,284–355` | This is the missing UI scope explicitly scheduled for Phase 3. |

## §3.3–§3.8 and revised build order

| Item | Section | Status | Evidence | Notes |
|---|---|---|---|---|
| Native lorebooks and RAG used; no lorebook rebuild | §3.3; §6.1 | DONE | `Mara_Sayegh_GobboNet_Card_Milestone3.json:7–11` (`loreEnabled`, `ragStorybook`); no custom lore engine in `customCode` | Existing native GobboNet lore/RAG remains in use. |
| TTS not implemented | §3.4 | DONE | Search of M3 `customCode` and ArcanaPersona `src/` found no TTS APIs or voice handlers | Correctly deferred. |
| STT not implemented | §3.5 | DONE | Same source search found no speech recognition, microphone, or STT handlers | Correctly deferred. |
| Call mode not implemented | §3.6 | DONE | Same source search found no call-mode or barge-in loop | Correctly deferred. |
| Deterministic decay and visible mood chip | §3.7 | PARTIAL | `soulScript.ts:329–355`; no HUD in M3 customCode | Decay exists; visible chip is part of the missing HUD. |
| Revised order item 1: psychology, deterministic decay, explicit no-op | §7.4(1) | DONE | M2 card’s `customCode`; M3 retains it (`soulScript.ts:284–355,947–998`) | M3 is the current parameterized descendant. |
| Revised order item 2: Diary and Archivist topics | §7.4(2) | DONE | M2 card’s `customCode`; M3 retains it (`soulScript.ts:154–168,998–1001,1034–1037`) | Includes mode-controlled passes and marker checks. |
| Revised order item 3: ArcanaPersona exports and carousel | §7.4(3) | DONE | M3 card; `arcanapersona/src/services/characterGenerator.ts:260–264,294–296,414–443`; `ExportHub.tsx:36–49` | M3 card carries enabled script and random carousel. |

## ArcanaPersona Milestone A verification

| Item | Section | Status | Evidence | Notes |
|---|---|---|---|---|
| Embedded script SHA-256 equals M3 card `customCode` | Milestone A | DONE | M3 `customCode` and `src/data/soul/soulScript.ts`; locally computed UTF-8 SHA-256: `38d0f9a2bf78d1053f30dbeec0b63f5fe1e1aa8d4bbcd9cf6bd25348ed6ace6d`; 76,084 bytes | The two byte strings hash identically. |
| `customCodeEnabled: true` on native, V2 and V3 generation | Milestone A | DONE | `characterGenerator.ts:260–264,292–296,438–443`; `ExportHub.tsx:42–47` | The export toggle is default-on (`ExportHub.tsx:21,280–288`); tests check generated native/V2 fields. |
| Carousel count, length, prefix, banned phrases, seeded determinism | Contract | DONE | `characterGenerator.ts:31–88,414–416`; `soulExport.test.ts:8–21,24–37` | Eight unique lines; maximum 100 chars; deterministic seeded output. |
| Toggle wiring, default on | Milestone A | DONE | `ExportHub.tsx:21,280–288,445–467` | Soul fields are stripped when disabled. |
| PNG round-trip with full script | Milestone A | DONE | `soulExport.test.ts:56–77`; `pngChunkWriter.ts:37–118` | Test deep-compares script, enabled flag, carousel and mode. |
| Canonical test command and current result | Milestone A | DONE | `package.json` has no `test` script; `bun test` run in `arcanapersona/` | Bun v1.4.4: 12 pass, 0 fail. Tests use `node:test`; no dependency install was needed. `bun test` is the working project command in this checkout. |
| Legacy `carouselPrompt: string[]` explicitly labeled legacy in export assembly | Hygiene review | PARTIAL | `characterGenerator.ts:438–443`; `ExportHub.tsx:36,159,459`; `types/character.ts:98–100` | The legacy array exists for consumers but has no explanatory comment. Phase 2a. |
| Stale M3 note that ArcanaPersona tasks remain | Hygiene review | PARTIAL | `MILESTONE3_NOTES.md` §(e) | Both Milestone A tasks are complete; Phase 2b. |
| PNG size and multi-card storage growth in notes | Hygiene review | PARTIAL | `ARCANAPERSONA_MILESTONE_A_NOTES.md:26,29–34` | PNG sizes are present, but not the per-card localStorage expectation or checkbox mitigation; Phase 2c. |
| Runner statement in notes | Hygiene review | PARTIAL | `ARCANAPERSONA_MILESTONE_A_NOTES.md:29–34`; `package.json` | Notes correctly report Bun passed, but incorrectly call Node `--import tsx` the project runner and say dependencies were unavailable. No `test` script exists. Phase 2d will state the verified runner precisely. |

## Summary

- PARTIAL: Diary display is fixed off; no settings UI yet (Phase 3 wires it).
- PARTIAL: continuity/psychology backups and full-index minimum-size checks are absent; topic backups and bounded field checks exist.
- PARTIAL: the visible mood chip/HUD is absent (Phase 3 builds it).
- PARTIAL: legacy carousel array needs a comment (Phase 2a).
- PARTIAL: ArcanaPersona notes omit storage-growth guidance (Phase 2c).
- PARTIAL: ArcanaPersona notes mischaracterize the test runner (Phase 2d).
- NOT DONE: settings surface and existing-state HUD specified by §§3.1, 3.2, 3.7 and 3.8 step 1 (Phase 3).
- NOT DONE / deferred: §3.2 `sow_variables` and `<state_update>` are not in revised §7.4 build order; would be separate scope.
- Deferred by design: TTS, STT, and call mode are not implemented and remain the next milestones after readiness.
- Source limitation: the dated v1 card named in the guide and pasted request was not found; M1–M3 exports are present and were audited.

## Ready for TTS?

**No, not yet.** Phase 3's specified existing-state HUD/settings UI is missing, and the current M3 card is not the required M4UI deliverable. TTS itself remains correctly out of scope for this audit.

## Phase 2–3 closure verification

The following audit gaps were closed after the initial findings above.

| Initial finding | Final status | Evidence |
|---|---|---|
| Diary display was fixed off and lacked a settings control | DONE | `arcanapersona/src/data/soul/soulScript.ts:168,196,1339,1466` — diary pass reads `maraUIv1.showDiaryInThread`; the settings checkbox writes it. |
| No real MaraSoul settings surface | DONE | M4UI card `customCode`; `soulScript.ts:1206–1470` — compact HUD, expansion, settings, modes, diary and visibility preferences. |
| Existing-state HUD and mood chip absent | DONE | `soulScript.ts:1206–1377` — relationship metrics, emotion/decay, psychology, life, facts, commitments, record counts and timestamp. |
| Legacy carousel array lacked a warning | DONE | `arcanapersona/src/services/characterGenerator.ts:438–439`. |
| Stale M3 ArcanaPersona checklist | DONE | `MILESTONE3_NOTES.md` §(e) now records Milestone A completion. |
| ArcanaPersona notes lacked growth guidance and accurate runner name | DONE | `ARCANAPERSONA_MILESTONE_A_NOTES.md` now records `bun test`, the measured test result and the requested distribution note. |
| Existing GobboNet card settings, behaviors and non-code fields | DONE | `Mara_Sayegh_GobboNet_Card_Milestone4UI.json`; all non-code values match M3 except `_import`; strict-mode customCode SHA-256 is recorded in Milestone 4UI notes. |
| Teardown/reset behavior | DONE (mocked) | `Mara_UI_test.html`; VM smoke exercised repeated activate/deactivate, thread-only reset, preserved intellectual ledger, mode/settings persistence and analysis error state. Live GobboNet card switching was unavailable. |

Items still outside this milestone's scope are listed under Summary and must be explicitly deferred in `TTS_READINESS.md`.
## Found but deferred

- Five-generation backups for per-thread relationship/psychology records and a full rewritten-index minimum-size guard are not in the current card. Topic backups, short topic/diary rejection and quote provenance checks are present. These were outside Milestone 4UI and are **deferred until after TTS**.
- §3.2's `sow_variables` prompt block and `<state_update>` parser remain outside revised §7.4 and are **deferred until after TTS**.
- The specifically named dated v1 GobboNet export was absent. M1–M3 were available and audited; no attempt was made to infer absent-card fields. This is a source limitation rather than an implementation blocker.
- Live GobboNet switching was unavailable. The included harness and VM smoke cover simulated activation/deactivation and orphan cleanup; a live card-switch check remains a manual verification item.
